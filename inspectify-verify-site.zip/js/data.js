// Loads /data/records.json once and builds in-memory indexes so every search after that
// is instant and needs no server. This file is shared by index.html and certificate.html.
const InspectifyData = (() => {
  let records = null;
  let bySerial = null;
  let byCode = null;
  let meta = null;

  async function load() {
    if (records) return;
    const [recRes, metaRes] = await Promise.all([fetch('data/records.json'), fetch('data/meta.json')]);
    records = await recRes.json();
    meta = await metaRes.json();
    bySerial = new Map(records.map((r) => [r.serialNumber.toLowerCase(), r]));
    byCode = new Map(records.map((r) => [r.verificationCode.toLowerCase(), r]));
  }

  function getMeta() { return meta; }

  function findBySerial(serial) {
    if (!serial) return null;
    return bySerial.get(serial.trim().toLowerCase()) || null;
  }

  function findByCode(code) {
    if (!code) return null;
    return byCode.get(code.trim().toLowerCase()) || null;
  }

  // Full search: unique number is authoritative; category/company are optional narrowing
  // filters that must agree with the record found, matching the original spec's
  // "category + company + unique number" search model.
  function search({ category, company, uniqueNumber }) {
    const record = findBySerial(uniqueNumber) || findByCode(uniqueNumber);
    if (!record) return { found: false };
    if (category && record.categoryCode !== category) return { found: false, mismatch: 'category' };
    if (company && record.companyName !== company) return { found: false, mismatch: 'company' };
    return { found: true, record };
  }

  return { load, getMeta, search, findByCode };
})();

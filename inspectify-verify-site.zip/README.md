# Inspectify — static verification site

A zero-backend version of the product verification page: search a device by its serial
number or certificate code, see PASS/FAIL, open a printable certificate with a QR code.
Everything — including all 10,000 real inspection records — is baked into static JSON at
build time, so there's no server, no database, and no API calls at runtime.

## Run it on your computer
No install needed. From this folder, either:
- Double-click `index.html`, **or**
- Run a tiny local server (needed if your browser blocks `fetch()` on `file://`):
  ```bash
  npx serve .
  # or: python3 -m http.server 8080
  ```
  then open the printed URL.

## Deploy to Netlify or Vercel — no settings required
This is a plain static site: just these files, nothing to build, no environment variables,
no functions. Either host will serve it correctly with its defaults.

**Netlify:** drag this whole folder onto https://app.netlify.com/drop — done. (Or connect
the repo; leave the build command blank and the publish directory as `.`.)

**Vercel:** `npx vercel` from this folder and accept every default (Framework: "Other",
Build command: none, Output directory: `.`). Or import the repo in the dashboard and accept
the defaults — Vercel auto-detects a framework-less static site.

The included `netlify.toml` / `vercel.json` just pin those same defaults explicitly so a
dashboard click can't accidentally change them — you don't need to open or edit either file.

## Updating the data
Replace `scripts/source.csv` with a newer export (same columns: `serial_number, category,
company_name, model_number, standard_followed, overall_status, inspection_date,
inspector_id, failure_reason, temperature_kelvin, power_draw_watts`), then:
```bash
node scripts/build-data.js
```
This regenerates `data/records.json` and `data/meta.json`. Re-deploy (drag the folder again,
or push to the connected repo) to publish the update. Certificate codes are generated
deterministically from the serial number, so they never change across rebuilds.

## What this version can't do (by design — it's backend-free)
It's read-only: no company login, no device registration, no submitting new inspections, no
file uploads, no admin console. Those need a real server and a real database, which a static
host fundamentally can't provide. For that full read/write platform — company portal,
dynamic inspection forms, PASS/FAIL engine, admin console — see the separate
`inspectify-platform` (Node/Express) folder in this delivery; run it locally with
`npm install && npm run dev`.

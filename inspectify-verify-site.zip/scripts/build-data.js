// Converts appliance_compliance_10000.csv into static JSON the browser can search
// instantly with no server, no database, and no API calls. Run once at build time
// (already run — see data/records.json); re-run after editing scripts/source.csv.
//
//   node scripts/build-data.js
//
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CSV_PATH = path.join(__dirname, 'source.csv');
const OUT_PATH = path.join(__dirname, '..', 'data', 'records.json');
const META_PATH = path.join(__dirname, '..', 'data', 'meta.json');

const CATEGORY_MAP = {
  'Weighing Scale': { code: 'WEIGHING_INSTRUMENT', name: 'Weighing Instrument' },
  'AC': { code: 'AIR_CONDITIONER', name: 'Air Conditioner' },
  'Fan': { code: 'FAN', name: 'Fan' },
  'Refrigerator': { code: 'REFRIGERATOR', name: 'Refrigerator' },
};

function parseCsv(text) {
  const lines = text.split(/\r?\n/).filter((l) => l.length > 0);
  const headers = lines[0].split(',').map((h) => h.trim());
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',');
    if (cols.length !== headers.length) continue;
    const row = {};
    headers.forEach((h, idx) => { row[h] = cols[idx].trim(); });
    rows.push(row);
  }
  return rows;
}

function ddmmyyyyToIso(d) {
  const m = /^(\d{2})-(\d{2})-(\d{4})$/.exec(d);
  if (!m) return d;
  return `${m[3]}-${m[2]}-${m[1]}`;
}

// Deterministic verification code so rebuilding the site never changes a device's public
// code: INS-<year>-<6 uppercase hex chars derived from a hash of the serial number>.
function verificationCode(serial, year) {
  const hash = crypto.createHash('sha256').update(serial).digest('hex').slice(0, 6).toUpperCase();
  return `INS-${year}-${hash}`;
}

function main() {
  const text = fs.readFileSync(CSV_PATH, 'utf8');
  const rows = parseCsv(text);

  const records = rows.map((row) => {
    const cat = CATEGORY_MAP[row.category] || { code: row.category.toUpperCase(), name: row.category };
    const isoDate = ddmmyyyyToIso(row.inspection_date);
    const year = isoDate.slice(0, 4);
    return {
      serialNumber: row.serial_number,
      verificationCode: verificationCode(row.serial_number, year),
      categoryCode: cat.code,
      categoryName: cat.name,
      companyName: row.company_name,
      modelNumber: row.model_number,
      standardName: row.standard_followed,
      result: row.overall_status === 'PASS' ? 'PASS' : 'FAIL',
      failureReason: row.failure_reason,
      inspectionDate: isoDate,
      temperatureKelvin: parseFloat(row.temperature_kelvin) || null,
      powerDrawWatts: parseFloat(row.power_draw_watts) || null,
      inspectorId: row.inspector_id,
    };
  });

  fs.mkdirSync(path.dirname(OUT_PATH), { recursive: true });
  fs.writeFileSync(OUT_PATH, JSON.stringify(records));

  const categories = [...new Set(records.map((r) => r.categoryCode))].map((code) => {
    const r = records.find((x) => x.categoryCode === code);
    return { code, name: r.categoryName };
  }).sort((a, b) => a.name.localeCompare(b.name));

  const companiesByCategory = {};
  for (const cat of categories) {
    companiesByCategory[cat.code] = [...new Set(records.filter((r) => r.categoryCode === cat.code).map((r) => r.companyName))].sort();
  }
  const allCompanies = [...new Set(records.map((r) => r.companyName))].sort();

  fs.writeFileSync(META_PATH, JSON.stringify({
    categories, allCompanies, companiesByCategory,
    totalRecords: records.length,
    passCount: records.filter((r) => r.result === 'PASS').length,
    failCount: records.filter((r) => r.result === 'FAIL').length,
    builtAt: new Date().toISOString(),
  }, null, 2));

  console.log(`Built ${records.length} records -> ${OUT_PATH}`);
  console.log(`Categories: ${categories.map((c) => c.name).join(', ')}`);
}

main();
